import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Place} from "../../models/place";

@Injectable({
  providedIn: 'root'
})
export class PlaceService {
  constructor(private http: HttpClient) {
  }

  getAllPlacesWithCrs = () => {
    return this.http.get('places?fields=id,name&expand=crs');
  }
  getAllPlaces = () => {
    return this.http.get('places');
  }
  deletePlace = (place_id: number) => {
    return this.http.delete('places' + place_id);
  }
  addPlace = (new_place: Place) => {
    return this.http.post('places', new_place);
  }
  editPlace = (updated_place: Place) => {
    return this.http.put('places/' + updated_place.id, updated_place);
  }
  searchPlace = (keyword: string) => {
    return this.http.get('places?filter[query]=' + keyword);
  }
  getCoordinates = (field_id: number) => {
    return this.http.get('coordinate/coordinate-reference-systems?fields=id,code,name');
  }
}
