import { Component, OnInit } from '@angular/core';
import {HeaderItemComponent} from "./header-item/header-item.component";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
